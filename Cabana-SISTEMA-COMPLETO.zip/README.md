# Cabaña — sistema completo preparado

Este paquete incluye:
- panel del propietario
- vista del huésped
- solicitud de fechas con aprobación/rechazo
- política de mascotas en dos lugares
- cancelación/reprogramación
- privacidad y seguridad
- calendario sin superposiciones
- desayuno y limpieza
- interruptores para WhatsApp, pagos y acceso
- campos para cargar credenciales de WhatsApp, Bancard y cerradura/controlador
- endpoints backend listos para WhatsApp, Bancard y apertura de puerta
- emergencias de luz/internet/portón contempladas
- PWA instalable

## Para activar después
### WhatsApp
Cargar:
- número
- Phone Number ID
- Access Token
- Verify Token
y activar WhatsApp.

### Bancard
Cargar:
- código de comercio
- código de sucursal
- clave pública
- clave privada
y activar pagos.

### Portón/puerta
Cargar:
- tipo de controlador
- endpoint/API
- token o clave
y activar acceso.

No se deben guardar claves reales en GitHub público.
