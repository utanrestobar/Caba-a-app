import {json,cors} from "../lib/http.js";
export default async function handler(req,res){if(cors(req,res))return;return json(res,200,{ok:true,whatsapp:!!(process.env.WA_TOKEN&&process.env.WA_PHONE_NUMBER_ID),payments:!!(process.env.BANCARD_PUBLIC_KEY&&process.env.BANCARD_PRIVATE_KEY),door:!!process.env.DOOR_ENDPOINT});}
